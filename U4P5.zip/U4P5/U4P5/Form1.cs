﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using CrystalDecisions.CrystalReports.Engine;
using CrystalDecisions.Shared;

namespace U4P5
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            ReportDocument cryrt = new ReportDocument();
            cryrt.Load(@"C:\Users\Abhishek\source\repos\U4P5\U4P5\CrystalReport1.rpt");
            crystalReportViewer1.ReportSource = cryrt;
            crystalReportViewer1.RefreshReport();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            ReportDocument cryrt = new ReportDocument();
            cryrt.Load(@"C:\Users\Abhishek\source\repos\U4P5\U4P5\CrystalReport2.rpt");
            crystalReportViewer1.ReportSource = cryrt;
            crystalReportViewer1.RefreshReport();

        }

        private void button3_Click(object sender, EventArgs e)
        {
            ReportDocument cryst = new ReportDocument();
            cryst.Load(@"C:\Users\Abhishek\source\repos\U4P5\U4P5\CrystalReport3.rpt");
            crystalReportViewer1.ReportSource = cryst;
            crystalReportViewer1.RefreshReport();
        }
    }
}
